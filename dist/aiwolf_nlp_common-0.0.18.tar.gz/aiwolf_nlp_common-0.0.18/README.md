# AIWolfNLP-Common

## 概要
人狼知能大会自然言語部門に参加する方向けのパッケージです。


## 手順
```
$ pip install --upgrade pip
$ pip install --upgrade setuptools
$ .venv/bin/pip install setuptools wheel
```