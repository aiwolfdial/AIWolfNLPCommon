from aiwolf_nlp_common import AIWolfNLPRole
from aiwolf_nlp_common.connection import SSHServer

print(AIWolfNLPRole.is_seer(role="SEER"))